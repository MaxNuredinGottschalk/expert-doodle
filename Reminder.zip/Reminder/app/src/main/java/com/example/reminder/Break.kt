package com.example.reminder

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.support.wearable.activity.WearableActivity
import android.view.View

class Break : WearableActivity() {

    // Class to suggest a break after continues mind-wandering

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_break)

        // Vibrate
        val vibrator = this.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vibrator.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))

        // Enables Always-on
        setAmbientEnabled()
    }

    fun yes(view : View){
        // Take a break
        val prefs = this.getSharedPreferences("com.example.reminder.prefs",0)
        val editor = prefs.edit()
        var count = 0
        // Write taken break into stats
        while(true){
            if(prefs.contains(count.toString())){
                count += 1
            }
            else{
                if(count != 0) {
                    count -= 1
                }
                var str = prefs.getString(count.toString(),"")
                editor.remove(count.toString())
                str += ",1b"
                editor.putString(count.toString(),str)
                editor.apply()
                break
            }
        }
        // Give saved variables to Timer
        val time = intent.getStringArrayExtra(setTime)
        val counter = intent.getIntExtra(setCounter,0)
        val scounter = intent.getIntExtra(setsCounter,0)
        val loss = 0
        val intent = Intent(this,BreakTimer::class.java)
        intent.putExtra(setTime,time)
        intent.putExtra(setCounter,counter)
        intent.putExtra(setsCounter,scounter)
        intent.putExtra(setLoss,loss)
        startActivity(intent)
    }

    fun no(view : View){
        // Take no break
        val prefs = this.getSharedPreferences("com.example.reminder.prefs",0)
        val editor = prefs.edit()
        var count = 0
        // Write into stats, that no break has been taken
        while(true){
            if(prefs.contains(count.toString())){
                count += 1
            }
            else{
                if(count != 0) {
                    count -= 1
                }
                var str = prefs.getString(count.toString(),"")
                editor.remove(count.toString())
                str += ",0b"
                editor.putString(count.toString(),str)
                editor.apply()
                break
            }
        }
        // Give saved variables to Timer
        val time = intent.getStringArrayExtra(setTime)
        val counter = intent.getIntExtra(setCounter,0)
        val scounter = intent.getIntExtra(setsCounter,0)
        val loss = 1
        val intent = Intent(this,Timer::class.java)
        intent.putExtra(setTime,time)
        intent.putExtra(setCounter,counter)
        intent.putExtra(setsCounter,scounter)
        intent.putExtra(setLoss,loss)
        startActivity(intent)
    }
}
