package com.example.reminder

import android.os.Bundle
import android.support.wearable.activity.WearableActivity
import android.content.Intent
import android.view.View

const val setCounter = "com.example.reminder.SETCOUNTER"

class Cancel : WearableActivity() {

    // Class to cancel a session

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cancel)

        // Enables Always-on
        setAmbientEnabled()
    }

    fun yes(view : View){
        // cancel session, mark session as cancelled in stats
        val intent = Intent(this,MainActivity::class.java)
        val prefs = this.getSharedPreferences("com.example.reminder.prefs",0)
        val editor = prefs.edit()
        var counter = 0
        while(true){
            if(prefs.contains(counter.toString())){
                counter += 1
            }
            else{
                if(counter != 0){
                    counter -= 1
                }
                var str = prefs.getString(counter.toString(),"")
                editor.remove(counter.toString())
                str += ",c"
                editor.putString(counter.toString(),str)
                editor.apply()
                break
            }
        }
        startActivity(intent)
    }

    fun no(view : View){
        // don't cancel session, give saved variables to Timer
        val time = intent.getStringArrayExtra(setTime)
        val counter = intent.getIntExtra(setCounter,0)
        val scounter = intent.getIntExtra(setsCounter,0)
        val loss = intent.getIntExtra(setLoss,0)
        val win = intent.getIntExtra(setWin,0)
        val intent = Intent(this,Timer::class.java)
        intent.putExtra(setTime,time)
        intent.putExtra(setWin,win)
        intent.putExtra(setCounter,counter)
        intent.putExtra(setsCounter,scounter)
        intent.putExtra(setLoss,loss)
        startActivity(intent)
    }

}
