package com.example.reminder

import android.content.Context
import android.os.Bundle
import android.support.wearable.activity.WearableActivity
import android.view.View
import android.content.Intent
import android.os.VibrationEffect
import android.os.Vibrator

class SessionEnd : WearableActivity() {

    // session has ended, return to main

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_session_end)

        val vibrator = this.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vibrator.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))

        // Enables Always-on
        setAmbientEnabled()
    }

    fun okay(view : View){
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }
}
