package com.example.reminder

import android.os.Bundle
import android.support.wearable.activity.WearableActivity
import android.widget.TextView
import android.view.View
import android.content.Intent
import android.widget.ArrayAdapter
import android.widget.Spinner

class SessionStats : WearableActivity() {

    // show stats of a certain session

    var stats : TextView? = null
    var spinner : Spinner? = null
    var spinner2 : Spinner? = null
    var spinner3 : Spinner? = null
    var spinner4 : Spinner? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_session_stats)

        val pref = getSharedPreferences("com.example.reminder.prefs",0)

        val counter = intent.getStringExtra(count)
        val sess = pref.getString(counter,"").toString().substringAfter(",")
        var rem = emptyArray<String>() //reminded notifications by time interval
        var acc = emptyArray<String>() //acceleration notification/fidgeting
        var brea = emptyArray<String>() //taken breaks
        var self = emptyArray<String>() //self recognized mind-wandering
        var canc = "" //session cancelled
        spinner = findViewById(R.id.spinner5)
        spinner2 = findViewById(R.id.spinner6)
        spinner3 = findViewById(R.id.spinner7)
        spinner4 = findViewById(R.id.spinner8)
        stats = findViewById(R.id.text2)
        val str = (counter!!.toInt() + 1).toString() +   ". " + pref.getString(counter,"")!!.substringBefore(",")
        for(i in 0..sess.length-1){
            if(sess[i] == '1'){
                if(i != sess.length-1)
                    if(sess[i+1] == 'm')
                        acc += "yes"
                    else if(sess[i+1] == 'b')
                        brea += "yes"
                    else if(sess[i+1] == 'n')
                        rem += "yes"
            }
            else if(sess[i] == '0'){
                if(i != sess.length-1)
                   if(sess[i+1] == 'm')
                       acc += "no"
                   else if(sess[i+1] == 'b')
                        brea += "no"
                   else if(sess[i+1] == 'n')
                        rem += "no"
            }
            else if(sess[i] == 'c')
                canc += "cancelled"
            else if(sess[i] == ':' && sess[i+3] == ':' && i+3 < sess.length-1){
                var selfstr = ""
                selfstr += sess[i-1]
                selfstr += sess[i-2]
                selfstr += sess[i]
                selfstr += sess[i+1]
                selfstr += sess[i+2]
                selfstr += sess[i+3]
                selfstr += sess[i+4]
                selfstr += sess[i+5]
                self += selfstr

                }
            }

        //display stats of session
        val out = "Reminded: " + "\n" + "Movement: " + "\n" + "Self: " + "\n" + "Break: " + "\n" + canc
        stats!!.text = out

        val arrayAdapter = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,rem)
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner!!.adapter = arrayAdapter

        val arrayAdapter2 = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,acc)
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner2!!.adapter = arrayAdapter2

        val arrayAdapter3 = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,self)
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner3!!.adapter = arrayAdapter3

        val arrayAdapter4 = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,brea)
        arrayAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner4!!.adapter = arrayAdapter4

        // Enables Always-on
        setAmbientEnabled()
    }

    fun back(view : View){
        // back to main
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }
}
