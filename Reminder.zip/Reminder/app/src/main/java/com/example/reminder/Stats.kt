package com.example.reminder

import android.os.Bundle
import android.support.wearable.activity.WearableActivity
import android.view.View
import android.widget.Spinner
import android.content.Intent
import android.widget.ArrayAdapter

const val count = "com.example.reminder.COUNT"

class Stats : WearableActivity() {

    // select session to show stats of in this activity

    var spinner : Spinner? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        // Enables Always-on
        setAmbientEnabled()

        //display saved sessions in spinner
        spinner = findViewById(R.id.spinner4)

        var arr  = emptyArray<String>()
        val prefs = this.getSharedPreferences("com.example.reminder.prefs",0)
        var counter = 0
        while(prefs.contains(counter.toString())){
            arr += (counter+1).toString() + ", " + prefs.getString(counter.toString(),"")!!.substringBefore(",")
            counter += 1
        }

        val arrayAdapter = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arr)
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner!!.adapter = arrayAdapter

    }

    fun back(view:View){
        //back to main
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }

    fun show(view: View){
        //show stats
        val counter = (spinner!!.selectedItem.toString().substringBefore(",").toInt()-1).toString()
        val intent = Intent(this,SessionStats::class.java).putExtra(count,counter)
        startActivity(intent)
    }
}
