package com.example.reminder

import android.os.Bundle
import android.support.wearable.activity.WearableActivity
import android.view.View
import android.content.Intent

class MainActivity : WearableActivity() {

    // Main Activity, choose here to start a new session or to show stats

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Enables Always-on
        setAmbientEnabled()
    }

    fun start(view : View){
        val intent = Intent(this,SetTime::class.java)
        startActivity(intent)

    }

    fun stats(view : View){
        val intent = Intent(this,Stats::class.java)
        startActivity(intent)
    }
}
