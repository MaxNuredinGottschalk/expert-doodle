package com.example.reminder

import android.os.Bundle
import android.support.wearable.activity.WearableActivity
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.view.View
import android.content.Intent
import java.time.LocalDate


const val setTime = "com.example.reminder.TIME"

class SetTime : WearableActivity() {

    // set the duration of a session in this activity

    // select min, hours and sec with spinners
    var spinner : Spinner? = null
    var spinner2 : Spinner? = null
    var spinner3 : Spinner? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_time)

        spinner = findViewById(R.id.spinner)
        spinner2 = findViewById(R.id.spinner2)
        spinner3 = findViewById(R.id.spinner3)


        ArrayAdapter.createFromResource(this,R.array.hours,
            android.R.layout.simple_spinner_item).also {
            adapter -> adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner!!.adapter = adapter
        }

        ArrayAdapter.createFromResource(this,R.array.minutes,
            android.R.layout.simple_spinner_item).also {
                adapter -> adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner2!!.adapter = adapter
        }

        ArrayAdapter.createFromResource(this,R.array.seconds,
            android.R.layout.simple_spinner_item).also {
                adapter -> adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner3!!.adapter = adapter
        }

        // Enables Always-on
        setAmbientEnabled()
    }

    fun start(view : View){
        // start session, save started session in stats and call timer with selected time
        val prefs = this.getSharedPreferences("com.example.reminder.prefs",0)
        val editor = prefs.edit()
        var counter = 0
        while(true){
            if(prefs.contains(counter.toString())){
                counter += 1
            }
            else{
                editor.putString(counter.toString(),LocalDate.now().toString())
                editor.apply()
                break
            }
        }
        val hours = spinner!!.selectedItem.toString()
        val minutes = spinner2!!.selectedItem.toString()
        val seconds = spinner3!!.selectedItem.toString()
        val time = arrayOf(hours,minutes,seconds)
        val intent = Intent(this,Timer::class.java)
        intent.putExtra(setTime,time)
        startActivity(intent)
    }
}
