package com.example.reminder

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.VibrationEffect
import android.os.Vibrator
import android.support.wearable.activity.WearableActivity
import android.widget.TextView
import android.view.View

class BreakTimer : WearableActivity() {

    // Class to show remaining time of a break

    val handler : Handler = Handler()
    var textView : TextView? = null
    var time : Array<String> = arrayOf("05","00","00") // 5 minutes

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_break_timer)

        createHandler(time)
        // Enables Always-on
        setAmbientEnabled()
    }

    fun stopHandler(){
        // Stop the break and Continue with Session
        // Give saved variables to Timer
        handler.removeCallbacksAndMessages(null)
        val times = intent.getStringArrayExtra(setTime)
        val counters = intent.getIntExtra(setCounter,0)
        val scounters = intent.getIntExtra(setsCounter,0)
        val loss = 0
        val vibrator = this.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vibrator.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
        val intent = Intent(this,Timer::class.java)
        intent.putExtra(setTime,times)
        intent.putExtra(setCounter,counters)
        intent.putExtra(setsCounter,scounters)
        intent.putExtra(setLoss,loss)
        startActivity(intent)
    }

    fun createHandler(array : Array<String>){
        // Handler to display passed time every second
        time = array

        val run : Runnable = object : Runnable {

            override fun run(){
                textView = findViewById(R.id.text)
                if(time[2] != "00"){
                    if(time[2].toInt() < 11){
                        time[2] = "0" + (time[2].toInt() -1).toString()
                    }
                    else {
                        time[2] = (time[2].toInt() - 1).toString()
                    }
                }
                else if(time[2] == "00" && time[1] != "00"){
                    if(time[1].toInt() < 11){
                        time[1] = "0" + (time[1].toInt() -1).toString()
                    }
                    else {
                        time[1] = (time[1].toInt() - 1).toString()
                    }
                    time[2] = "59"
                }
                else if(time[1] == "00" && time[0] != "00"){
                    if(time[0].toInt() < 11){
                        time[0] = "0" + (time[0].toInt() -1).toString()
                    }
                    else {
                        time[0] = (time[0].toInt() - 1).toString()
                    }
                    time[1] = "59"
                    time[2] = "59"
                }
                else{
                    stopHandler()
                    return
                }
                val str = time[0] + ":" + time[1] + ":" + time[2]
                textView!!.text = str
                handler.postDelayed(this,1000)
            }
        }

        handler.post(run)
    }

    fun stop(view : View){
        stopHandler()
    }
}
