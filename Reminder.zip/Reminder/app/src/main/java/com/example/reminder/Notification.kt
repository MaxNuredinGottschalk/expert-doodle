package com.example.reminder

import android.content.Intent
import android.os.Bundle
import android.support.wearable.activity.WearableActivity
import android.view.View
import android.os.Vibrator
import android.content.Context
import android.os.VibrationEffect

class Notification : WearableActivity() {

    // Notification send in time intervals to remind the user

    var loss = 0 // variable to check amount of mind-wandering

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)

        loss = intent.getIntExtra(setLoss,0)

        // vibrate
        val vibrator = this.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vibrator.vibrate(VibrationEffect.createOneShot(400,VibrationEffect.DEFAULT_AMPLITUDE))

        // Enables Always-on
        setAmbientEnabled()
    }

    fun yes(view : View){
        // person has mind-wandered, save in stats and increase loss
        val prefs = this.getSharedPreferences("com.example.reminder.prefs",0)
        val editor = prefs.edit()
        var counter = 0
        loss += 1
        while(true){
            if(prefs.contains(counter.toString())){
                counter += 1
            }
            else{
                if(counter != 0){
                    counter -= 1
                }
                var str = prefs.getString(counter.toString(),"")
                editor.remove(counter.toString())
                str += ",1n"
                editor.putString(counter.toString(),str)
                editor.apply()
                break
            }
        }
        // Get back to Timer with saved Variables
        val time = intent.getStringArrayExtra(setTime)
        val win = intent.getIntExtra(setWin,0)
        val intent = Intent(this,Timer::class.java)
        intent.putExtra(setTime,time)
        intent.putExtra(setLoss,loss)
        intent.putExtra(setWin,win)
        startActivity(intent)
    }

    fun no(view : View){
        // person did not mind-wander, save in stats and reset loss
        val prefs = this.getSharedPreferences("com.example.reminder.prefs",0)
        val editor = prefs.edit()
        var counter = 0
        loss = 0
        while(true){
            if(prefs.contains(counter.toString())){
                counter += 1
            }
            else{
                if(counter != 0) {
                    counter -= 1
                }
                var str = prefs.getString(counter.toString(),"")
                editor.remove(counter.toString())
                str += ",0n"
                editor.putString(counter.toString(),str)
                editor.apply()
                break
            }
        }
        // Get back to Timer with saved Variables
        val time = intent.getStringArrayExtra(setTime)
        val win = intent.getIntExtra(setWin,0)
        val intent = Intent(this,Timer::class.java)
        intent.putExtra(setTime,time)
        intent.putExtra(setWin,win)
        intent.putExtra(setLoss,loss)
        startActivity(intent)
    }
}
