package com.example.reminder

import android.content.Context
import android.os.Bundle
import android.support.wearable.activity.WearableActivity
import android.widget.TextView
import android.os.Handler
import android.content.Intent
import android.view.View
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.abs
import android.view.WindowManager

const val setsCounter = "com.example.reminder.sCounter"
const val setLoss = "com.example.reminder.LOSS"
const val setWin = "com.example.reminder.WIN"

class Timer : WearableActivity(), SensorEventListener {

    // Timer activity : shows remaining time of a current session

    private lateinit var sensorManager : SensorManager
    private var accel : Sensor? = null
    val handler : Handler = Handler() // handler to display time every second
    var textView : TextView? = null
    var curTime : Array<String>? = null
    var time : Array<String> = arrayOf("0","0","0")
    var counter = 0 //counter for notification to be send
    var scounter = 0 //counter for sensor to check acceleration
    //buffer counters
    var curCounter = 0
    var cursCounter = 0
    var loss = 0 //amount of mind-wandering
    var win = 0 //amount of not-mind-wandering
    var sensorChange = false //boolean to check sensor every 3 seconds
    // variables to compare acceleration change
    var xs = 0.00.toFloat()
    var ys = 0.00.toFloat()
    var zs = 0.00.toFloat()

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timer)
        //keep screen on
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        //initialise acceleration sensor
        sensorManager = this.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        //initialise variables
        loss = intent.getIntExtra(setLoss,0)
        win = intent.getIntExtra(setWin, 0)
        time = intent.getStringArrayExtra(setTime)!!
        counter = intent.getIntExtra(setCounter,0)
        scounter = intent.getIntExtra(setsCounter,0)

        if(loss >= 3){
            //suggest a break after continues mind-wandering
            handler.removeCallbacksAndMessages(null)
            val intent = Intent(this,Break::class.java)
            curTime = time
            curCounter = counter
            cursCounter = scounter
            intent.putExtra(setTime,curTime)
            intent.putExtra(setCounter,curCounter)
            intent.putExtra(setsCounter,cursCounter)
            intent.putExtra(setLoss,loss)
            intent.putExtra(setWin,win)
            startActivity(intent)
        }

        // Enables Always-on
        setAmbientEnabled()

    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {

    }

    override fun onSensorChanged(event: SensorEvent) {
        //check here if continues fidgeting is happening

        if (sensorChange) {
            sensorChange = false
            scounter = 0
            if(event.sensor.type == Sensor.TYPE_LINEAR_ACCELERATION) {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]

                if(xs != 0.toFloat()) {
                    if(xs > 0.10 || ys > 0.10 || zs > 0.10) {
                        //compare previous acceleration with current to determine continues movement
                        if (abs(x - xs) < 1 || abs(y - ys) < 1 || abs(z - zs) < 1)
                            send_move_noti()
                    }
                }
                xs = x
                ys = y
                zs = z
            }
        }
    }

    override fun onResume() {
        super.onResume()
        win = intent.getIntExtra(setWin, 0)
        if (win < 2)
            //don't register sensor until next notification, if person has not mind-wandered at wrist movement
            accel?.also { acc ->
                sensorManager.registerListener(
                    this,
                    acc,
                    SensorManager.SENSOR_DELAY_NORMAL
                )
            }
        else{
            sensorManager.unregisterListener(this)
            win = 0
        }
        loss = intent.getIntExtra(setLoss,0)
        val times = intent.getStringArrayExtra(setTime)
        val counters = intent.getIntExtra(setCounter,0)
        val scounters = intent.getIntExtra(setsCounter,0)
        createHandler(times!!,counters,scounters) // create the handler for the timer

    }

    override fun onPause() {
        //unregister sensor on pause to save battery
        super.onPause()
        sensorManager.unregisterListener(this)
        handler.removeCallbacksAndMessages(null)

    }

    fun stopHandler(){
        // Session has ended
        handler.removeCallbacksAndMessages(null)
        val intent = Intent(this,SessionEnd::class.java)
        startActivity(intent)
    }

    fun send_noti(){
        // send time based notification
        handler.removeCallbacksAndMessages(null)
        val intent = Intent(this,Notification::class.java)
        intent.putExtra(setTime,curTime)
        intent.putExtra(setLoss,loss)
        intent.putExtra(setWin,win)
        startActivity(intent)
    }

    fun send_move_noti(){
        // send movement based notification
        handler.removeCallbacksAndMessages(this)
        val intent = Intent(this,NotificationMovement::class.java)
        intent.putExtra(setTime,curTime)
        intent.putExtra(setWin,win)
        intent.putExtra(setLoss,loss)
        startActivity(intent)
    }

    fun self_mw(view : View){
        // user marks time, if recognizes mind-wandering
        loss += 1
        if(loss >= 3) {
            //suggest a break after continues mind-wandering
            handler.removeCallbacksAndMessages(null)
            val intent = Intent(this, Break::class.java)
            curTime = time
            curCounter = counter
            cursCounter = scounter
            intent.putExtra(setTime, curTime)
            intent.putExtra(setCounter, curCounter)
            intent.putExtra(setsCounter, cursCounter)
            intent.putExtra(setLoss, loss)
            intent.putExtra(setWin, win)
            startActivity(intent)
        }

        val vibrator = this.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        val prefs = this.getSharedPreferences("com.example.reminder.prefs",0)
        val editor = prefs.edit()
        var counter = 0
        while(true){
            if(prefs.contains(counter.toString())){
                counter += 1
            }
            else{
                if(counter != 0){
                    counter -= 1
                }
                var str = prefs.getString(counter.toString(),"")
                editor.remove(counter.toString())

                str += ','
                val text = textView!!.text
                str += text
                editor.putString(counter.toString(),str)
                editor.apply()
                break
            }
        }
    }

    fun stop(view: View){
        //end session
        handler.removeCallbacksAndMessages(null)
        val intent = Intent(this,Cancel::class.java)
        curTime = time
        curCounter = counter
        cursCounter = scounter
        intent.putExtra(setTime,curTime)
        intent.putExtra(setCounter,curCounter)
        intent.putExtra(setsCounter,cursCounter)
        intent.putExtra(setLoss,loss)
        intent.putExtra(setWin,win)
        startActivity(intent)
    }

    fun createHandler(array : Array<String>,count : Int,scount : Int){
        //handler to call run() every second and display time left,
        //also checks, based on counters, to send notifications(time or movement based)
        time = array
        counter = count
        scounter = scount

        val run : Runnable = object : Runnable {

            override fun run(){
                textView = findViewById(R.id.text)
                if(time[2] != "00"){
                    if(time[2].toInt() < 11){
                        time[2] = "0" + (time[2].toInt() -1).toString()
                    }
                    else {
                        time[2] = (time[2].toInt() - 1).toString()
                    }
                }
                else if(time[2] == "00" && time[1] != "00"){
                    if(time[1].toInt() < 11){
                        time[1] = "0" + (time[1].toInt() -1).toString()
                    }
                    else {
                        time[1] = (time[1].toInt() - 1).toString()
                    }
                    time[2] = "59"
                }
                else if(time[1] == "00" && time[0] != "00"){
                    if(time[0].toInt() < 11){
                        time[0] = "0" + (time[0].toInt() -1).toString()
                    }
                    else {
                        time[0] = (time[0].toInt() - 1).toString()
                    }
                    time[1] = "59"
                    time[2] = "59"
                }
                else{
                    // time over
                    stopHandler()
                    return
                }
                //display time on textview
                val str = time[0] + ":" + time[1] + ":" + time[2]
                textView!!.text = str
                handler.postDelayed(this,1000)
                counter += 1
                scounter += 1
                if(scounter == 3){
                    //check acceleration every 3 seconds
                    cursCounter = scounter
                    curTime = time
                    sensorChange = true
                }
                if(counter == 600 && !(time[0] == "00" && time[1] == "00" && time[2] == "00")){
                    // send notification every 10 minutes
                    curCounter = 0
                    curTime = time
                    send_noti()
                }
            }
        }

        handler.post(run)
    }

}
